# Finanzas Familiares

Aplicación web para controlar ingresos, gastos, deudas, ahorro y presupuesto familiar. Funciona 100% en el navegador (HTML + CSS + JavaScript puro), sin necesidad de servidor ni instalación.

## Cómo publicarla en GitHub Pages (gratis)

1. Crea un repositorio nuevo en GitHub (por ejemplo `finanzas-familia`).
2. Sube **todo** el contenido de esta carpeta (`index.html`, la carpeta `css/` y la carpeta `js/`) a la raíz del repositorio.
   - Puedes arrastrar los archivos directamente en la web de GitHub ("Add file" → "Upload files"), o usar Git desde tu computadora.
3. Entra a **Settings → Pages** del repositorio.
4. En "Source" elige la rama `main` y la carpeta `/ (root)`, luego guarda.
5. Espera 1-2 minutos. GitHub te dará un enlace como:
   `https://tu-usuario.github.io/finanzas-familia/`
6. Abre ese enlace desde el celular o la computadora — ya puedes usar la app desde cualquier lado.

## Cómo funciona el acceso

Al abrir la app eliges entre dos usuarios (Administrador y Cónyuge). No hay contraseña real: es un selector simple, ya que todos los datos se guardan **localmente en el navegador de cada dispositivo** (con `localStorage`), igual que tus módulos de Punto Escolar.

**Importante:** esta versión NO sincroniza en tiempo real entre dispositivos. Si tú registras un gasto desde tu celular, tu esposa no lo verá automáticamente en el suyo — cada navegador tiene su propia copia de los datos. Si más adelante quieres sincronización real entre ambos, se necesita un backend (por ejemplo Supabase), y puedo ayudarte a construir esa versión cuando la necesites.

## Respaldo de datos

Desde **Configuración → Copia de seguridad** puedes exportar toda tu información a un archivo `.json` y volver a importarla cuando quieras (por ejemplo, para pasar tus datos de un dispositivo a otro, o como respaldo).

## Estructura del proyecto

```
finanzas-familia/
├── index.html          # estructura de la página
├── css/
│   └── styles.css      # diseño (colores, tipografía, componentes)
├── js/
│   ├── icons.js         # librería de íconos SVG
│   ├── storage.js       # capa de datos (localStorage, categorías, CRUD)
│   └── app.js            # lógica de la aplicación (vistas, formularios, gráficos)
└── README.md
```

## Módulos incluidos

- **Dashboard**: balance del mes, gráficos, gastos recientes, próximos pagos.
- **Ingresos**: registro con categoría, persona, recurrencia y observaciones.
- **Gastos**: registro con categoría, método de pago, persona y descripción; filtros y búsqueda.
- **Deudas**: saldo pendiente que se actualiza solo al registrar pagos parciales.
- **Ahorro**: metas con depósitos y porcentaje alcanzado.
- **Presupuesto**: límite mensual por categoría con alertas amarilla (80%) y roja (100%).
- **Recordatorios**: próximos pagos (alquiler, servicios, cuotas, etc.).
- **Papelera**: nada se borra para siempre por accidente — todo se puede restaurar.
- **Reportes**: mensual, anual, deudas pendientes y evolución del ahorro, con exportación a CSV (se abre en Excel) e impresión a PDF.
- **Búsqueda global** en la barra superior.
- **Modo claro/oscuro** desde el ícono de la barra lateral o en Configuración.

## Notas técnicas

- Los gráficos usan [Chart.js](https://www.chartjs.org/) cargado desde un CDN, por lo que se necesita conexión a internet para verlos (el resto de la app funciona sin conexión una vez cargada).
- Las tipografías (Fraunces, Inter, IBM Plex Mono) se cargan desde Google Fonts.
